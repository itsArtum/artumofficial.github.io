Welcome!
The manual can be found at

http://gmnet.parakoopa.de

The licenses can be found in LICENSE.txt